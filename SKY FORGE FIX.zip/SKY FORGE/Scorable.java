public interface Scorable {
    int getScoreValue();// semua objek yang ketika ditembak, menghasilkan score
}