public interface Collectible {
    void onCollect(p2 player); // semua objek yang dapat di collect (ambil) oleh player (p2)
}
