public interface Shootable {
    void shoot(); // semua objek yang dapat menembak
}